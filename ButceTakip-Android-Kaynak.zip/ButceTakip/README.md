# Bütçe Takip — Android kaynak kodu

Android Studio'da `ButceTakip` klasörünü açın. Gradle senkronizasyonunu tamamlayın (internet gerekir). **Build > Build Bundle(s) / APK(s) > Build APK(s)** ile APK oluşturun. APK genellikle `app/build/outputs/apk/debug/app-debug.apk` konumundadır.

Özellikler: TL gelir/gider kaydı, aylık bakiye ve kategori raporu, bekleyen ödemeler, ödeme tarihinden 1 gün önce yaklaşık 09:00'da yerel bildirim. Veriler cihazda SharedPreferences içinde saklanır. Bildirim izni verilmelidir. Android pil optimizasyonları bildirimleri geciktirebilir; yeniden başlatma sonrası alarmlar yeniden planlanmaz. Bu başlangıç sürümüdür, üretim sürümü değildir. Uygulamayı silmek verileri silebilir; yedekleme özelliği henüz yoktur.
