package com.ornek.butcetakip

import android.Manifest
import android.app.*
import android.content.*
import android.content.pm.PackageManager
import android.graphics.Color
import android.os.*
import android.view.*
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : Activity() {
 private lateinit var root: LinearLayout
 private val prefs by lazy { getSharedPreferences("records", MODE_PRIVATE) }
 private val money = NumberFormat.getCurrencyInstance(Locale("tr", "TR"))
 private val bg = Color.rgb(13,20,31)
 private val panel = Color.rgb(29,39,54)
 private val white = Color.WHITE
 private val green = Color.rgb(17,167,98)
 private val red = Color.rgb(213,74,72)
 override fun onCreate(savedInstanceState: Bundle?) { super.onCreate(savedInstanceState); window.statusBarColor=bg; window.navigationBarColor=bg
  if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED) requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
  showHome()
 }
 private fun records(): JSONArray = try { JSONArray(prefs.getString("items","[]")) } catch (_:Exception) { JSONArray() }
 private fun save(arr: JSONArray) { prefs.edit().putString("items",arr.toString()).apply() }
 private fun txt(s:String, size:Float=18f, color:Int=white): TextView = TextView(this).apply { text=s; textSize=size; setTextColor(color); setPadding(12,12,12,12) }
 private fun button(s:String,color:Int,action:()->Unit): Button = Button(this).apply { text=s; setTextColor(white); setBackgroundTintList(android.content.res.ColorStateList.valueOf(color)); setOnClickListener { action() } }
 private fun screen(title:String) { root=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL; setBackgroundColor(bg); setPadding(18,24,18,18) }; val scroll=ScrollView(this); scroll.addView(root); setContentView(scroll); root.addView(txt(title,26f)) }
 private fun addCard(s:String) { root.addView(txt(s,18f).apply { setBackgroundColor(panel); setPadding(22,20,22,20) }) }
 private fun showHome() {
  screen("☰   Bütçe Takip     ♧")
  val a=records(); var income=0.0; var expense=0.0
  val now=Calendar.getInstance(); val upcoming=mutableListOf<JSONObject>()
  for(i in 0 until a.length()) { val o=a.getJSONObject(i); val date=o.optLong("time"); val type=o.optString("type"); val amount=o.optDouble("amount")
   if(type=="Gelir" || type=="Gider") { val c=Calendar.getInstance().apply { timeInMillis=date }; if(c.get(Calendar.YEAR)==now.get(Calendar.YEAR)&&c.get(Calendar.MONTH)==now.get(Calendar.MONTH)) { if(type=="Gelir") income+=amount else expense+=amount } }
   if(type=="Ödeme" && !o.optBoolean("paid") && date >= System.currentTimeMillis()-86400000L) upcoming.add(o)
  }
  addCard("BU AY  •  ${SimpleDateFormat("MMMM yyyy", Locale("tr","TR")).format(Date())}\n\nKalan Bakiye\n${money.format(income-expense)}\n\n🟢 Gelir: ${money.format(income)}\n🔴 Gider: ${money.format(expense)}")
  root.addView(button("＋ Gelir Ekle",green){ entry("Gelir") }); root.addView(button("− Gider Ekle",red){ entry("Gider") })
  root.addView(button("▣ Ödeme Ekle",Color.rgb(91,65,163)){ entry("Ödeme") }); root.addView(button("▥ Aylık Rapor",Color.rgb(29,93,174)){ report() })
  root.addView(txt("Yaklaşan Ödemeler",22f))
  upcoming.sortBy { it.optLong("time") }
  if(upcoming.isEmpty()) root.addView(txt("Henüz bekleyen ödeme yok."))
  upcoming.take(12).forEach { o -> val date=SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")).format(Date(o.optLong("time"))); root.addView(button("${o.optString("name")}  •  ${money.format(o.optDouble("amount"))}\n$date   ✓ Ödendi",panel){ o.put("paid",true); save(a); showHome() }) }
  root.addView(button("Tüm İşlemler",panel){ history() })
 }
 private fun entry(type:String) {
  screen("←   $type Ekle"); root.addView(button("Geri",panel){showHome()})
  val name=EditText(this).apply { hint=if(type=="Gelir") "Açıklama (ör. Maaş)" else "Kategori / açıklama"; setTextColor(white); setHintTextColor(Color.LTGRAY) }
  val amount=EditText(this).apply { hint="Tutar (₺)"; inputType=8194; setTextColor(white); setHintTextColor(Color.LTGRAY) }
  root.addView(name); root.addView(amount)
  val date=DatePicker(this); if(type=="Ödeme") { root.addView(txt("Son ödeme tarihi")); root.addView(date) }
  root.addView(button("Kaydet",green){
   val value=amount.text.toString().replace(',','.').toDoubleOrNull()
   if(value==null || !value.isFinite() || value<=0 || value>1e12 || name.text.isBlank()) { Toast.makeText(this,"Açıklama ve geçerli tutar girin",Toast.LENGTH_SHORT).show(); return@button }
   val time=if(type=="Ödeme") Calendar.getInstance().apply { set(date.year,date.month,date.dayOfMonth,9,0,0); set(Calendar.MILLISECOND,0) }.timeInMillis else System.currentTimeMillis()
   val o=JSONObject().put("name",name.text.toString().trim()).put("amount",value).put("type",type).put("time",time).put("paid",false)
   val arr=records(); arr.put(o); save(arr)
   if(type=="Ödeme") schedule(o,arr.length()-1)
   showHome()
  })
 }
 private fun schedule(o:JSONObject,id:Int) {
  val mgr=getSystemService(ALARM_SERVICE) as AlarmManager
  val intent=Intent(this,ReminderReceiver::class.java).putExtra("name",o.optString("name")).putExtra("amount",money.format(o.optDouble("amount")))
  val pi=PendingIntent.getBroadcast(this,id,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  val whenMs=o.optLong("time")-24*60*60*1000L
  if(whenMs>System.currentTimeMillis()) mgr.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,whenMs,pi)
 }
 private fun report() {
  screen("Aylık Rapor"); root.addView(button("← Ana Sayfa",panel){showHome()})
  val totals=linkedMapOf<String,Double>(); var income=0.0
  val now=Calendar.getInstance(); val arr=records()
  for(i in 0 until arr.length()) { val o=arr.getJSONObject(i); val c=Calendar.getInstance().apply {timeInMillis=o.optLong("time")}; if(c.get(Calendar.YEAR)!=now.get(Calendar.YEAR)||c.get(Calendar.MONTH)!=now.get(Calendar.MONTH)) continue
   if(o.optString("type")=="Gelir") income+=o.optDouble("amount")
   if(o.optString("type")=="Gider") { val k=o.optString("name"); totals[k]=(totals[k]?:0.0)+o.optDouble("amount") }
  }
  val total=totals.values.sum(); addCard("Gelir: ${money.format(income)}\nGider: ${money.format(total)}\nKalan: ${money.format(income-total)}")
  totals.toList().sortedByDescending {it.second}.forEach { (k,v)-> val pct=if(total>0) (v/total*100).toInt() else 0; addCard("$k  •  ${money.format(v)}  (%$pct)"); val bar=ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal).apply { max=100; progress=pct }; root.addView(bar) }
 }
 private fun history() { screen("Tüm İşlemler"); root.addView(button("← Ana Sayfa",panel){showHome()}); val a=records(); for(i in a.length()-1 downTo 0) { val o=a.getJSONObject(i); addCard("${o.optString("type")}: ${o.optString("name")}\n${money.format(o.optDouble("amount"))} • ${SimpleDateFormat("dd.MM.yyyy",Locale("tr","TR")).format(Date(o.optLong("time")))}${if(o.optBoolean("paid")) " • Ödendi" else ""}") } }
 @Deprecated("Deprecated in Java") override fun onBackPressed() {showHome()}
}

class ReminderReceiver: android.content.BroadcastReceiver() {
 override fun onReceive(context:Context,intent:Intent) {
  val manager=context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
  val channel="payments"
  if(Build.VERSION.SDK_INT>=26) manager.createNotificationChannel(NotificationChannel(channel,"Ödeme Hatırlatmaları",NotificationManager.IMPORTANCE_HIGH))
  val notification=Notification.Builder(context,channel).setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Yarın ödeme var").setContentText("${intent.getStringExtra("name")}: ${intent.getStringExtra("amount")}").setAutoCancel(true).build()
  if(Build.VERSION.SDK_INT<33 || context.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)==PackageManager.PERMISSION_GRANTED) manager.notify((System.currentTimeMillis()%Int.MAX_VALUE).toInt(),notification)
 }
}
